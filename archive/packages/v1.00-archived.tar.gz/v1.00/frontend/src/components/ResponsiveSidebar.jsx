import { Link, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { useLanguage } from '../i18n/LanguageProvider'
import {
  LayoutDashboard,
  Building2,
  Package,
  Leaf,
  Users,
  FolderOpen,
  Lightbulb,
  FileText,
  Receipt,
  Camera,
  Calendar,
  Settings,
  X,
  Shield,
  Eye,
  Bot
} from 'lucide-react'

const ResponsiveSidebar = ({ isOpen, onClose, user }) => {
  const location = useLocation()
  const { t, currentLanguage } = useLanguage()

  const navigation = [
    { 
      name: t('navigation.dashboard', 'Dashboard'), 
      href: '/dashboard', 
      icon: LayoutDashboard,
      roles: ['admin', 'employee', 'client']
    },
    { 
      name: t('navigation.suppliers', 'Suppliers'), 
      href: '/suppliers', 
      icon: Building2,
      roles: ['admin', 'employee']
    },
    { 
      name: t('navigation.products', 'Products'), 
      href: '/products', 
      icon: Package,
      roles: ['admin', 'employee']
    },
    { 
      name: t('navigation.plants', 'Plants'), 
      href: '/plants', 
      icon: Leaf,
      roles: ['admin', 'employee']
    },
    { 
      name: t('navigation.clients', 'Clients'), 
      href: '/clients', 
      icon: Users,
      roles: ['admin', 'employee']
    },
    { 
      name: t('navigation.projects', 'Projects'), 
      href: '/projects', 
      icon: FolderOpen,
      roles: ['admin', 'employee', 'client']
    },
    { 
      name: t('navigation.timeline', 'Project Timeline'), 
      href: '/timeline', 
      icon: Calendar,
      roles: ['admin', 'employee', 'client']
    },
    { 
      name: t('plants.recommendations', 'Plant Recommendations'), 
      href: '/plant-recommendations', 
      icon: Lightbulb,
      roles: ['admin', 'employee', 'client']
    },
    { 
      name: t('navigation.reports', 'Reports'), 
      href: '/reports', 
      icon: FileText,
      roles: ['admin', 'employee']
    },
    { 
      name: t('aiAssistant.title', 'AI Assistant'), 
      href: '/ai-assistant', 
      icon: Bot,
      roles: ['admin', 'employee']
    },
    { 
      name: t('invoices.title', 'Invoices & Quotes'), 
      href: '/invoices', 
      icon: Receipt,
      roles: ['admin', 'employee']
    },
    { 
      name: t('navigation.photos', 'Photo Gallery'), 
      href: '/photos', 
      icon: Camera,
      roles: ['admin', 'employee', 'client']
    },
    { 
      name: t('navigation.settings', 'Settings'), 
      href: '/settings', 
      icon: Settings,
      roles: ['admin', 'employee', 'client']
    },
  ]

  // Filter navigation based on user role
  const getFilteredNavigation = () => {
    if (!user) return navigation
    
    return navigation.filter(item => {
      if (!item.roles) return true
      return item.roles.includes(user.role)
    })
  }

  const getRoleIcon = (role) => {
    switch (role) {
      case 'admin':
        return Shield
      case 'employee':
        return Users
      case 'client':
        return Eye
      default:
        return Users
    }
  }

  const getRoleColor = (role) => {
    switch (role) {
      case 'admin':
        return 'text-red-600 bg-red-100'
      case 'employee':
        return 'text-blue-600 bg-blue-100'
      case 'client':
        return 'text-green-600 bg-green-100'
      default:
        return 'text-gray-600 bg-gray-100'
    }
  }

  const getRoleDisplay = (role) => {
    return t(`auth.roles.${role}`, role);
  }

  // Prevent body scroll when sidebar is open on mobile
  useEffect(() => {
    if (isOpen) {
      document.body.classList.add('sidebar-open')
    } else {
      document.body.classList.remove('sidebar-open')
    }

    return () => {
      document.body.classList.remove('sidebar-open')
    }
  }, [isOpen])

  // Close sidebar on escape key
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape' && isOpen) {
        onClose()
      }
    }

    document.addEventListener('keydown', handleEscape)
    return () => document.removeEventListener('keydown', handleEscape)
  }, [isOpen, onClose])

  return (
    <>
      {/* Backdrop - only visible on mobile when sidebar is open */}
      {isOpen && (
        <div
          className="sidebar-backdrop lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar */}
      <aside
        className={`sidebar-container ${isOpen ? 'open' : ''}`}
        role="navigation"
        aria-label="Main navigation"
      >
        {/* Logo and close button */}
        <div className="sidebar-logo">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-green-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
                {t('dashboard.title', 'Landscape')}
              </h1>
              <p className="text-sm text-gray-500">
                {t('dashboard.welcome', 'Architecture Tool')}
              </p>
            </div>
          </div>
          
          <button
            onClick={onClose}
            className="sidebar-close-btn lg:hidden"
            aria-label={t('common.close', 'Close sidebar')}
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* User Information */}
        {user && (
          <div className="px-4 py-3 border-b border-gray-200 bg-gray-50 mx-4 rounded-lg mb-4">
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                user.role === 'admin' ? 'bg-red-600' :
                user.role === 'employee' ? 'bg-blue-600' : 'bg-green-600'
              }`}>
                {user.username.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">
                  {user.username}
                </p>
                <div className="flex items-center space-x-1">
                  {(() => {
                    const RoleIcon = getRoleIcon(user.role)
                    return <RoleIcon className="w-3 h-3 text-gray-500" />
                  })()}
                  <p className="text-xs text-gray-500">
                    {getRoleDisplay(user.role)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Navigation */}
        <nav className="sidebar-navigation" aria-label="Main menu">
          <ul className="sidebar-nav-list">
            {getFilteredNavigation().map((item) => {
              const isActive = location.pathname === item.href
              return (
                <li key={item.name} className="sidebar-nav-item">
                  <Link
                    to={item.href}
                    onClick={onClose} // Always close sidebar when navigating on mobile
                    className={`sidebar-nav-link ${isActive ? 'active' : ''}`}
                    aria-current={isActive ? 'page' : undefined}
                  >
                    <item.icon className={`sidebar-nav-icon ${isActive ? 'active' : ''}`} />
                    <span>{item.name}</span>
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>

        {/* Sidebar Footer */}
        <div className="mt-auto p-4 border-t border-gray-200">
          <div className="text-center">
            <p className="text-xs text-gray-500">
              © 2025 {currentLanguage === 'nl' ? 'Landschapsarchitectuur' : 'Landscape Architecture'}
            </p>
            <p className="text-xs text-gray-400 mt-1">
              v1.0.0
            </p>
          </div>
        </div>
      </aside>
    </>
  )
}

export default ResponsiveSidebar

